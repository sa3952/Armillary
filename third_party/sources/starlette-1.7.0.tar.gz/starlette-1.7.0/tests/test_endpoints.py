from collections.abc import Iterator

import pytest

from starlette import status
from starlette.endpoints import HTTPEndpoint, WebSocketEndpoint
from starlette.requests import Request
from starlette.responses import PlainTextResponse
from starlette.routing import Route, Router
from starlette.testclient import TestClient
from starlette.types import Message
from starlette.websockets import WebSocket
from tests.types import TestClientFactory


class Homepage(HTTPEndpoint):
    async def get(self, request: Request) -> PlainTextResponse:
        username = request.path_params.get("username")
        if username is None:
            return PlainTextResponse("Hello, world!")
        return PlainTextResponse(f"Hello, {username}!")

    async def query(self, request: Request) -> PlainTextResponse:
        return PlainTextResponse("Hello, QUERY!")


app = Router(routes=[Route("/", endpoint=Homepage), Route("/{username}", endpoint=Homepage)])


@pytest.fixture
def client(test_client_factory: TestClientFactory) -> Iterator[TestClient]:
    with test_client_factory(app) as client:
        yield client


def test_http_endpoint_route(client: TestClient) -> None:
    response = client.get("/")
    assert response.status_code == 200
    assert response.text == "Hello, world!"


def test_http_endpoint_route_path_params(client: TestClient) -> None:
    response = client.get("/tomchristie")
    assert response.status_code == 200
    assert response.text == "Hello, tomchristie!"


def test_http_endpoint_route_method(client: TestClient) -> None:
    response = client.post("/")
    assert response.status_code == 405
    assert response.text == "Method Not Allowed"
    assert response.headers["allow"] == "GET, QUERY"


def test_http_endpoint_route_query_method(client: TestClient) -> None:
    response = client.request("QUERY", "/")
    assert response.status_code == 200
    assert response.text == "Hello, QUERY!"


def test_http_endpoint_does_not_dispatch_non_verb_method(test_client_factory: TestClientFactory) -> None:
    class Endpoint(HTTPEndpoint):
        async def get(self, request: Request) -> PlainTextResponse:
            return PlainTextResponse("Hello, world!")  # pragma: no cover

        async def _do_delete(self, request: Request) -> PlainTextResponse:
            return PlainTextResponse("Privileged helper")  # pragma: no cover

    app = Router(routes=[Route("/", endpoint=Endpoint)])
    client = test_client_factory(app)

    response = client.request("_DO_DELETE", "/")
    assert response.status_code == 405
    assert response.text == "Method Not Allowed"
    assert response.headers["allow"] == "GET"


def test_websocket_endpoint_on_connect(test_client_factory: TestClientFactory) -> None:
    class WebSocketApp(WebSocketEndpoint):
        async def on_connect(self, websocket: WebSocket) -> None:
            assert websocket["subprotocols"] == ["soap", "wamp"]
            await websocket.accept(subprotocol="wamp")

    client = test_client_factory(WebSocketApp)
    with client.websocket_connect("/ws", subprotocols=["soap", "wamp"]) as websocket:
        assert websocket.accepted_subprotocol == "wamp"


def test_websocket_endpoint_on_receive_bytes(
    test_client_factory: TestClientFactory,
) -> None:
    class WebSocketApp(WebSocketEndpoint):
        encoding = "bytes"

        async def on_receive(self, websocket: WebSocket, data: bytes) -> None:
            await websocket.send_bytes(b"Message bytes was: " + data)

    client = test_client_factory(WebSocketApp)
    with client.websocket_connect("/ws") as websocket:
        websocket.send_bytes(b"Hello, world!")
        _bytes = websocket.receive_bytes()
        assert _bytes == b"Message bytes was: Hello, world!"

    with pytest.raises(RuntimeError):
        with client.websocket_connect("/ws") as websocket:
            websocket.send_text("Hello world")


def test_websocket_endpoint_on_receive_json(
    test_client_factory: TestClientFactory,
) -> None:
    class WebSocketApp(WebSocketEndpoint):
        encoding = "json"

        async def on_receive(self, websocket: WebSocket, data: str) -> None:
            await websocket.send_json({"message": data})

    client = test_client_factory(WebSocketApp)
    with client.websocket_connect("/ws") as websocket:
        websocket.send_json({"hello": "world"})
        data = websocket.receive_json()
        assert data == {"message": {"hello": "world"}}

    with pytest.raises(RuntimeError):
        with client.websocket_connect("/ws") as websocket:
            websocket.send_text("Hello world")


def test_websocket_endpoint_on_receive_json_binary(
    test_client_factory: TestClientFactory,
) -> None:
    class WebSocketApp(WebSocketEndpoint):
        encoding = "json"

        async def on_receive(self, websocket: WebSocket, data: str) -> None:
            await websocket.send_json({"message": data}, mode="binary")

    client = test_client_factory(WebSocketApp)
    with client.websocket_connect("/ws") as websocket:
        websocket.send_json({"hello": "world"}, mode="binary")
        data = websocket.receive_json(mode="binary")
        assert data == {"message": {"hello": "world"}}


def test_websocket_endpoint_on_receive_text(
    test_client_factory: TestClientFactory,
) -> None:
    class WebSocketApp(WebSocketEndpoint):
        encoding = "text"

        async def on_receive(self, websocket: WebSocket, data: str) -> None:
            await websocket.send_text(f"Message text was: {data}")

    client = test_client_factory(WebSocketApp)
    with client.websocket_connect("/ws") as websocket:
        websocket.send_text("Hello, world!")
        _text = websocket.receive_text()
        assert _text == "Message text was: Hello, world!"

    with pytest.raises(RuntimeError):
        with client.websocket_connect("/ws") as websocket:
            websocket.send_bytes(b"Hello world")


def test_websocket_endpoint_on_default(test_client_factory: TestClientFactory) -> None:
    class WebSocketApp(WebSocketEndpoint):
        encoding = None

        async def on_receive(self, websocket: WebSocket, data: str) -> None:
            await websocket.send_text(f"Message text was: {data}")

    client = test_client_factory(WebSocketApp)
    with client.websocket_connect("/ws") as websocket:
        websocket.send_text("Hello, world!")
        _text = websocket.receive_text()
        assert _text == "Message text was: Hello, world!"


def test_websocket_endpoint_on_default_with_empty_text(test_client_factory: TestClientFactory) -> None:
    class WebSocketApp(WebSocketEndpoint):
        encoding = None

        async def on_receive(self, websocket: WebSocket, data: str) -> None:
            await websocket.send_text(f"Message text was: {data!r}")

    client = test_client_factory(WebSocketApp)
    with client.websocket_connect("/ws") as websocket:
        websocket.send_text("")
        _text = websocket.receive_text()
        assert _text == "Message text was: ''"


@pytest.mark.anyio
async def test_websocket_endpoint_decode_text_rejects_message_without_text() -> None:
    # Per the ASGI spec, "one or both keys may be present" on a receive event, so a
    # compliant server may send both "text" and "bytes", with "text" set to None.
    class Echo(WebSocketEndpoint):
        encoding = "text"

    sent: list[Message] = []

    async def receive() -> Message:
        raise AssertionError("receive should not be called")  # pragma: no cover

    async def send(message: Message) -> None:
        sent.append(message)

    ep = Echo({"type": "websocket", "path": "/", "headers": [], "query_string": b""}, receive=receive, send=send)
    websocket = WebSocket(ep.scope, receive=ep.receive, send=send)
    message: Message = {"type": "websocket.receive", "text": None, "bytes": b"hello"}

    with pytest.raises(RuntimeError, match="Expected text websocket messages, but got bytes"):
        await ep.decode(websocket, message)

    assert sent == [{"type": "websocket.close", "code": status.WS_1003_UNSUPPORTED_DATA, "reason": ""}]


@pytest.mark.anyio
async def test_websocket_endpoint_decode_bytes_rejects_message_without_bytes() -> None:
    class Echo(WebSocketEndpoint):
        encoding = "bytes"

    sent: list[Message] = []

    async def receive() -> Message:
        raise AssertionError("receive should not be called")  # pragma: no cover

    async def send(message: Message) -> None:
        sent.append(message)

    ep = Echo({"type": "websocket", "path": "/", "headers": [], "query_string": b""}, receive=receive, send=send)
    websocket = WebSocket(ep.scope, receive=ep.receive, send=send)
    message: Message = {"type": "websocket.receive", "text": "hi", "bytes": None}

    with pytest.raises(RuntimeError, match="Expected bytes websocket messages, but got text"):
        await ep.decode(websocket, message)

    assert sent == [{"type": "websocket.close", "code": status.WS_1003_UNSUPPORTED_DATA, "reason": ""}]


def test_websocket_endpoint_on_disconnect(
    test_client_factory: TestClientFactory,
) -> None:
    class WebSocketApp(WebSocketEndpoint):
        async def on_disconnect(self, websocket: WebSocket, close_code: int) -> None:
            assert close_code == 1001
            await websocket.close(code=close_code)

    client = test_client_factory(WebSocketApp)
    with client.websocket_connect("/ws") as websocket:
        websocket.close(code=1001)
