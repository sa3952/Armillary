Version history
===============

This library adheres to `Semantic Versioning 2.0 <http://semver.org/>`_.

**4.15.1**

- Implemented a compatibility fix for supporting direct access of ``anyio.*`` submodules
  from the main package even when those submodules were not directly imported first
  (`#1311 <https://github.com/agronholm/anyio/issues/1311>`)

**4.15.0**

- Added support for the newer keyword-only arguments on ``anyio.Path`` methods to match
  the standard library ``pathlib.Path``:

  * ``follow_symlinks`` on ``exists()`` (Python 3.12+)
  * ``follow_symlinks`` on ``is_dir()`` (Python 3.13+)
  * ``follow_symlinks`` on ``is_file()`` (Python 3.13+)
  * ``follow_symlinks`` on ``owner()`` (Python 3.13+)
  * ``follow_symlinks`` on ``group()`` (Python 3.13+)
  * ``newline`` on ``read_text()`` (Python 3.13+)

  (`#1286 <https://github.com/agronholm/anyio/pull/1286>`_,
  `#1293 <https://github.com/agronholm/anyio/pull/1293>`_; PR by @jaideeppyne)
- Added ``amap``, ``gather``, and ``as_completed`` utility functions to simplify common
  patterns (`#1173 <https://github.com/agronholm/anyio/pull/1173>`_; PR by @Graeme22)
- Added ``--anyio-mode`` command-line option as an alternative to the ``anyio_mode``
  ini setting, and fix the pytest plugin's auto mode detection to recognize the mode
  when set via either mechanism(e.g: ``pytest_asyncio``).
  (`#1242 <https://github.com/agronholm/anyio/pull/1242>`_; PR by @EmmanuelNiyonshuti)
- Added the ``anyio.Future`` synchronization primitive which behaves similar to
  ``asyncio.Future``, allowing tasks to wait for a value (or exception) from another
  task (`#1146 <https://github.com/agronholm/anyio/pull/1146>`_; PR by @Vizonex)
- Added guidance for managing multiple memory object stream producers and consumers
  with cloned streams
  (`#330 <https://github.com/agronholm/anyio/issues/330>`_; PR by @nightcityblade)
- Added ``StapledObjectStream.send_nowait()`` that delegates to the underlying
  ``ObjectSendStream``, if it implements it
  (`#1241 <https://github.com/agronholm/anyio/pull/1241>`_; PR by @davidbrochart)
- Added the ``move_on_at()`` and ``fail_at()`` functions to complement
  ``move_on_after()`` and ``fail_after()``
- Changed the default name for a task spawned with ``TaskGroup.create_task(func())`` to
  match the default task name for the analogous task spawned with
  ``TaskGroup.start_soon(func)`` or ``TaskGroup.start(func)`` in more situations.
  Previously, the default name of a ``TaskGroup.create_task`` task never included the
  module name. (The default name for a task spawned with ``TaskGroup.start_soon`` or
  ``TaskGroup.start`` typically includes the module name.)
  (`#1234 <https://github.com/agronholm/anyio/pull/1234>`_; PR by @gschaffner)
- Changed the ``anyio`` and ``anyio.abc`` modules to lazily (much like :pep:`810`)
  import the necessary submodules. This is done by parsing the AST of the module and
  building a lookup table from the ``if TYPE_CHECKING:`` block. A fallback mode has been
  provided for installations where the source code is unavailable (e.g. PyInstaller).
  (`#1169 <https://github.com/agronholm/anyio/pull/1169>`_)
- Fixed free-threading compatibility issues arising from the fact that on Python 3.14
  free-threading builds, newly created threads inherit the current context by default,
  causing AnyIO to behave erroneously in relation to ``start_blocking_portal()`` and
  ``anyio.to_thread.run_sync()``
  (`#1224 <https://github.com/agronholm/anyio/pull/1224>`_; PR by @EmmanuelNiyonshuti)
- Fixed ``SpooledTemporaryFile.readinto()`` and ``readinto1()`` reading twice before
  rollover, so the destination buffer was overwritten by the second read and the file
  position advanced twice, silently losing data
  (`#1215 <https://github.com/agronholm/anyio/pull/1215>`_; PR by @c-tonneslan)
- Added a ``reason`` parameter to ``fail_after`` (and the new ``fail_at``) allowing for
  added exception context when raising ``TimeoutError``
  (`#1227 <https://github.com/agronholm/anyio/pull/1227>`_; PR by @Graeme22)
- Fixed the default ``TaskHandle.name`` missing part of the task name for tasks started
  with ``TaskGroup.start`` on Trio (`#1231
  <https://github.com/agronholm/anyio/issues/1231>`_; PR by @gschaffner)
- Fixed ``anyio.run`` leaking, or at least, delaying collection of loop and root_task
  due to the root task being cached in a ``RunVar``.
  (`#1203 <https://github.com/agronholm/anyio/issues/1203>`_; PR by @tapetersen)
- Fixed ``anyio.Path.with_stem()`` silently producing a wrong path (e.g.
  ``Path(".txt")``) instead of raising ``ValueError`` when given an empty stem on a
  path with a non-empty suffix, unlike :meth:`pathlib.PurePath.with_stem`
  (`#1200 <https://github.com/agronholm/anyio/pull/1200>`_; PR by @Sanjays2402)
- Fixed ``UNIXSocketStream.aclose()`` raising ``asyncio.InvalidStateError`` when a
  concurrent receive or send operation had just been cancelled on the asyncio backend
  (`#1267 <https://github.com/agronholm/anyio/issues/1267>`_; PR by @alloutflo)
- Fixed the pytest plugin importing the deprecated ``_pytest.python.CallSpec2`` alias,
  which triggers ``PytestRemovedIn10Warning`` on ``pytest>=9.2`` and crashes pytest at
  startup when ``filterwarnings = error`` is configured
  (`#1271 <https://github.com/agronholm/anyio/issues/1271>`_; PR by @matthewfeickert)
- Fixed an asyncio worker thread race that could raise ``RuntimeError`` when the event
  loop closed between checking its state and scheduling the worker result
  (`#1265 <https://github.com/agronholm/anyio/issues/1265>`_; PR by @hansu650)
- Fixed ``CapacityLimiter`` on the asyncio backend over-granting tokens when
  ``total_tokens`` was raised while the limiter was over-subscribed
  (`#1223 <https://github.com/agronholm/anyio/pull/1223>`_; PR by @zelinewang)
- Fixed asyncio task groups leaking unawaited coroutines when a custom task constructor
  fails; default task creation is unaffected
  (`#1274 <https://github.com/agronholm/anyio/issues/1274>`_; PR by @dsfaccini)
- Fixed inconsistencies between Trio and asyncio when target ``TaskGroup`` is
  cancelled before a task created with ``.start()`` calls ``TaskStatus.started()``

  * The started task shouldn't get a ``CancelledError`` until the first
    checkpoint after the ``started()`` call.
  * A value passed to ``started()`` should be available on the ``TaskHandle``
    and correctly passed back to the caller of start even if cancelled.
  * The CancelledError shouldn't leak out of the ``TaskGroup.start()`` call to the calling
    task.

  (`#1197 <https://github.com/agronholm/anyio/issues/1197>`_; PR by @tapetersen)
- Fixed ``TemporaryDirectory`` not cleaning up when the host task was cancelled while
  exiting the context manager, as the cleanup now runs in a shielded cancel scope
  (`#1304 <https://github.com/agronholm/anyio/pull/1304>`_; PR by @smurfix)

**4.14.2**

- Changed ``ByteReceiveStream.receive()`` implementations to raise a ``ValueError`` when
  ``max_bytes`` is not a positive integer
  (`#1191 <https://github.com/agronholm/anyio/pull/1191>`_)
- Fixed ``CapacityLimiter.total_tokens`` rejecting ``float("inf")`` when the limiter was
  instantiated outside of an event loop. The adapter setter checked for infinity by
  identity (``value is math.inf``), so only the exact ``math.inf`` singleton was accepted,
  while every backend setter (using ``math.isinf()``) accepts any positive infinity
  (`#1189 <https://github.com/agronholm/anyio/pull/1189>`_; PR by @greymoth-jp).
- Fixed ``to_process.run_sync()`` deadlocking when the worker function writes enough data
  to ``sys.stderr`` to fill the (undrained) pipe buffer. The worker process now redirects
  ``sys.stderr`` to ``os.devnull`` as well, matching the documented behavior
- Fixed ``TLSStream.wrap()`` matching an internationalized (unicode) host name against
  the peer certificate using IDNA 2003 (via the standard library) instead of IDNA 2008,
  which could cause the host name to be matched against the wrong certificate
  (`#1208 <https://github.com/agronholm/anyio/pull/1208>`_)
- Fixed ``anyio.open_process()`` (and ``run_process()``) ignoring the ``extra_groups``
  argument, as it mistakenly passed the value of the ``group`` argument instead
  (`#1209 <https://github.com/agronholm/anyio/pull/1209>`_)
- Fixed ``CapacityLimiter.acquire_nowait()`` and
  ``CapacityLimiter.acquire_nowait_on_behalf_of()`` raising ``trio.WouldBlock`` instead
  of ``anyio.WouldBlock`` on the ``trio`` backend when there are no tokens available
  (`#1218 <https://github.com/agronholm/anyio/pull/1218>`_)
- Fixed ``CapacityLimiter`` on the asyncio backend over-granting tokens
  (``borrowed_tokens`` exceeding ``total_tokens`` and ``available_tokens`` going
  negative) when a non-blocking acquire was made in the window between a token
  being released and the notified waiter resuming. The freed token is now
  reserved for the woken waiter right away, so the non-blocking acquire correctly
  raises ``WouldBlock``
  (`#1170 <https://github.com/agronholm/anyio/issues/1170>`_; PR by @gaoflow)
- Fixed unnecessary CPU spin when delivering cancellation from ``CancelScope`` on
  asyncio under certain conditions, including improper cancel scope nesting
  (`#1111 <https://github.com/agronholm/anyio/issues/1111>`_)

**4.14.1**

- Fixed teardown of higher-scoped async fixtures failing on asyncio with
  ``RuntimeError: Attempted to exit cancel scope in a different task than it was entered in``
  when an async test raise an outcome exception (e.g., ``pytest.skip()``, ``pytest.xfail()``,
  or ``pytest.fail()``)
  (`#1179 <https://github.com/agronholm/anyio/issues/1179>`_; PR by @EmmanuelNiyonshuti)
- Fixed ``CapacityLimiter.total_tokens`` rejecting a value of ``0`` when the limiter was
  instantiated outside of an event loop, contradicting the documented behavior of
  allowing 0 total tokens
  (`#1183 <https://github.com/agronholm/anyio/pull/1183>`_; PR by @nyxst4ck)
- Fixed ``Process.wait()`` on asyncio waiting for stdout/stderr kept open (e.g.
  if a grandchild inherited it), instead of returning once the process exits
  like the other backends do
  (`#1174 <https://github.com/agronholm/anyio/issues/1174>`_; PR by @tapetersen)
- Fixed ``Process.aclose()`` deadlocking on the asyncio backend when the subprocess is
  blocked on writing to a stdout or stderr pipe whose buffer is full; closing the
  process's standard streams now also closes the underlying pipe transports
  (`#1166 <https://github.com/agronholm/anyio/issues/1166>`_; PR by @tapetersen)

**4.14.0**

- Added support for Python 3.15
- Added an asynchronous implementation of the ``itertools`` module
  (`#998 <https://github.com/agronholm/anyio/issues/998>`_; PR by @11kkw)
- Added the ``local_port`` parameter to ``connect_tcp()`` to allow binding to a
  specific local port before connecting
  (`#1067 <https://github.com/agronholm/anyio/issues/1067>`_; PR by @nullwiz)
- Added support for custom capacity limiters in async path and file I/O
  functions and classes
- Added the ``create_task()`` task group method for easier asyncio migration (returns a
  ``TaskHandle``)
  (`#1098 <https://github.com/agronholm/anyio/pull/1098>`_)
- Changed ``TaskGroup.start_soon()`` to return a ``TaskHandle``
- Added an option for ``TaskGroup.start()`` to return a ``TaskHandle`` (which then
  contains the start value in the ``start_value`` property)
- Added the ``cancel()`` convenience method to ``TaskGroup`` as a shortcut for
  cancelling the task group's cancel scope
- Improved the error message when a known backend is not installed to suggest the
  install command
  (`#1115 <https://github.com/agronholm/anyio/pull/1115>`_; PR by @EmmanuelNiyonshuti)
- Improved ``anyio.Path`` to preserve subclass types by returning ``Self`` in methods
  that return path objects
  (`#1130 <https://github.com/agronholm/anyio/issues/1130>`_; PR by @EmmanuelNiyonshuti)
- Changed the parameter type annotation in ``anyio.Path.write_bytes()`` to accept
  any ``ReadableBuffer``, thus allowing it to accept ``bytearray`` and ``memoryview`` to
  match ``pathlib.Path.write_bytes()``
  (`#1135 <https://github.com/agronholm/anyio/issues/1135>`_; PR by @SAY-5)
- Changed several type annotations to only accept callables returning coroutine-like
  objects instead of arbitrary awaitables:

  - ``TaskGroup.start_soon()``
  - ``TaskGroup.start()``
  - ``anyio.from_thread.run()``

  This reverts an earlier change from v3.7.0 which was made in error.
  (`#1153 <https://github.com/agronholm/anyio/pull/1153>`_)
- Changed ``anyio.run`` to support callables returning arbitrary awaitables at runtime
  on all backends. Previously, this only worked on asyncio (`#1171
  <https://github.com/agronholm/anyio/pull/1171>`_; PR by @gschaffner)
- Changed several classes (and their subclasses) to have ``__slots__`` (with
  ``__weakref__``):

  * ``anyio.CancelScope``
  * ``anyio.CapacityLimiter``
  * ``anyio.Condition``
  * ``anyio.Event``
  * ``anyio.Lock``
  * ``anyio.ResourceGuard``
  * ``anyio.Semaphore``
- Fixed cancellation exception escaping a cancel scope when triggered via
  ``check_cancelled()`` in a worker thread
  (`#1113 <https://github.com/agronholm/anyio/issues/1113>`_)
- Fixed ``TaskGroup`` raising ``AttributeError`` instead of a clear error when entered
  more than once
  (`#1109 <https://github.com/agronholm/anyio/issues/1109>`_; PR by @bahtya)
- Fixed lost type information when passing arguments to ``lru_cache``
  (`#1104 <https://github.com/agronholm/anyio/pull/1104>`_; PR by @Graeme22)
- Fixed test resumption after ``KeyboardInterrupt`` in async generator fixtures on the
  asyncio backend
  (`#1060 <https://github.com/agronholm/anyio/issues/1060>`_; PR by @EmmanuelNiyonshuti)
- Fixed import of ``__main__`` in ``to_process`` workers when entrypoint script
  doesn't end in ``.py``, such as when using ``console_script`` entrypoints.
  (`#1027 <https://github.com/agronholm/anyio/issues/1027>`_; PR by @tapetersen)
- Fixed ``SocketListener.from_socket()`` returning a TCP listener for ``AF_UNIX``
  listening sockets, causing ``accept()`` to fail with ``ENOTSUP``
  (`#1132 <https://github.com/agronholm/anyio/issues/1132>`_; PR by @kudato)
- Fixed ``UDPSocket.aclose()`` and ``ConnectedUDPSocket.aclose()`` on asyncio returning
  before the underlying socket FD was actually released
  (`#1147 <https://github.com/agronholm/anyio/pull/1147>`_; PR by @matias-arrelid)
- Fixed trio backend test runner hanging indefinitely instead of raising an error
  when dynamically accessing an async fixture via ``request.getfixturevalue``
  (`#1148 <https://github.com/agronholm/anyio/issues/1148>`_; PR by @EmmanuelNiyonshuti)
- Fixed cancelling tasks started through a ``BlockingPortal`` after the portal has been
  stopped
  (`#1013 <https://github.com/agronholm/anyio/issues/1013>`_; PR by @puneetdixit200)
- Fixed ``backend_options`` being ignored when running the Trio backend via
  ``anyio.run()``; the options are now passed as keyword arguments to ``trio.run()``
  again, as documented (a regression from AnyIO 3)
  (`#1161 <https://github.com/agronholm/anyio/pull/1161>`_; PR by @Zac-HD)
- Fixed asyncio ``Lock`` and ``Semaphore`` deadlocks caused by cancelled waiters
  left queued during release
  (`#1145 <https://github.com/agronholm/anyio/pull/1145>`_; PR by @rasmusfaber,
  @x42005e1f and @agronholm)

**4.13.0**

- Dropped support for Python 3.9
- Added a ``ttl`` parameter to the ``anyio.functools.lru_cache`` wrapper
  (`#1073 <https://github.com/agronholm/anyio/pull/1073>`_; PR by @Graeme22)
- Widened the type annotations of file I/O streams to accept ``IO[bytes]``
  instead of just ``BinaryIO``
  (`#1078 <https://github.com/agronholm/anyio/issues/1078>`_)
- Fixed ``anyio.Path`` not being compatible with Python 3.15 due to the removal of
  ``pathlib.Path.is_reserved()`` and the addition of ``pathlib.Path.__vfspath__()``
  (`#1061 <https://github.com/agronholm/anyio/issues/1061>`_; PR by @veeceey)
- Fixed the ``BrokenResourceError`` raised by the asyncio ``SocketStream`` not having
  the original exception as its cause
  (`#1055 <https://github.com/agronholm/anyio/issues/1055>`_; PR by @veeceey)
- Fixed the ``TypeError`` raised when using "func" as a parameter name in
  ``pytest.mark.parametrize`` when using the pytest plugin
  (`#1068 <https://github.com/agronholm/anyio/pull/1068>`_; PR by @JohnnyDeuss)
- Fixed the pytest plugin not running tests that had the ``anyio`` marker added
  programmatically via ``pytest_collection_modifyitems``
  (`#422 <https://github.com/agronholm/anyio/issues/422>`_; PR by @chbndrhnns)
- Fixed cancellation exceptions leaking from a ``CancelScope`` on asyncio when they are
  contained in an exception group alongside non-cancellation exceptions (`#1091
  <https://github.com/agronholm/anyio/issues/1091>`_; PR by @gschaffner)
- Fixed ``Condition.wait()`` not passing on a notification when the task is cancelled
  but already received a notification
- Fixed inverted condition in the process pool shutdown phase which would cause
  still-running pooled processes not to be terminated
  (`#1074 <https://github.com/agronholm/anyio/pull/1074>`_; PR by @bysiber)

**4.12.1**

- Changed all functions currently raising the private ``NoCurrentAsyncBackend``
  exception (since v4.12.0) to instead raise the public ``NoEventLoopError`` exception
  (`#1048 <https://github.com/agronholm/anyio/issues/1048>`_)
- Fixed ``anyio.functools.lru_cache`` not working with instance methods
  (`#1042 <https://github.com/agronholm/anyio/issues/1042>`_)

**4.12.0**

- Added support for asyncio's `task call graphs`_ on Python 3.14 and later when using
  AnyIO's task groups
  (`#1025 <https://github.com/agronholm/anyio/pull/1025>`_)
- Added an asynchronous implementation of the ``functools`` module
  (`#1001 <https://github.com/agronholm/anyio/pull/1001>`_)
- Added support for ``uvloop=True`` on Windows via the winloop_ implementation
  (`#960 <https://github.com/agronholm/anyio/pull/960>`_; PR by @Vizonex)
- Added support for use as a context manager to ``anyio.lowlevel.RunVar``
  (`#1003 <https://github.com/agronholm/anyio/pull/1003>`_)
- Added ``__all__`` declarations to public submodules (``anyio.lowlevel`` etc.)
  (`#1009 <https://github.com/agronholm/anyio/pull/1009>`_)
- Added the ability to set the token count of a ``CapacityLimiter`` to zero
  (`#1019 <https://github.com/agronholm/anyio/pull/1019>`_; requires Python 3.10 or
  later when using Trio)
- Added parameters ``case_sensitive`` and ``recurse_symlinks`` along with support for
  path-like objects to ``anyio.Path.glob()`` and ``anyio.Path.rglob()``
  (`#1033 <https://github.com/agronholm/anyio/pull/1033>`_; PR by @northisup)
- Dropped ``sniffio`` as a direct dependency and added the ``get_available_backends()``
  function (`#1021 <https://github.com/agronholm/anyio/pull/1021>`_)
- Fixed ``Process.stdin.send()`` not raising ``ClosedResourceError`` and
  ``BrokenResourceError`` on asyncio. Previously, a non-AnyIO exception was raised in
  such cases (`#671 <https://github.com/agronholm/anyio/issues/671>`_; PR by
  @gschaffner)
- Fixed ``Process.stdin.send()`` not checkpointing before writing data on asyncio
  (`#1002 <https://github.com/agronholm/anyio/issues/1002>`_; PR by @gschaffner)
- Fixed a race condition where cancelling a ``Future`` from
  ``BlockingPortal.start_task_soon()`` would sometimes not cancel the async function
  (`#1011 <https://github.com/agronholm/anyio/issues/1011>`_; PR by @gschaffner)
- Fixed the presence of the pytest plugin causing breakage with older versions of
  pytest (<= 6.1.2)
  (`#1028 <https://github.com/agronholm/anyio/issues/1028>`_; PR by @saper)
- Fixed a rarely occurring ``RuntimeError: Set changed size during iteration`` while
  shutting down the process pool when using the asyncio backend
  (`#985 <https://github.com/agronholm/anyio/issues/985>`_)

.. _task call graphs: https://docs.python.org/3/library/asyncio-graph.html
.. _winloop: https://github.com/Vizonex/Winloop

**4.11.0**

- Added support for cancellation reasons (the ``reason`` parameter to
  ``CancelScope.cancel()``)
  (`#975 <https://github.com/agronholm/anyio/pull/975>`_)
- Bumped the minimum version of Trio to v0.31.0
- Added the ability to enter the event loop from foreign (non-worker) threads by
  passing the return value of ``anyio.lowlevel.current_token()`` to
  ``anyio.from_thread.run()`` and ``anyio.from_thread.run_sync()`` as the ``token``
  keyword argument (`#256 <https://github.com/agronholm/anyio/issues/256>`_)
- Added pytest option (``anyio_mode = "auto"``) to make the pytest plugin automatically
  handle all async tests
  (`#971 <https://github.com/agronholm/anyio/pull/971>`_)
- Added the ``anyio.Condition.wait_for()`` method for feature parity with asyncio
  (`#974 <https://github.com/agronholm/anyio/pull/974>`_)
- Changed the default type argument of ``anyio.abc.TaskStatus`` from ``Any`` to ``None``
  (`#964 <https://github.com/agronholm/anyio/pull/964>`_)
- Fixed TCP listener behavior to guarantee the same ephemeral port is used for all
  socket listeners when ``local_port=0``
  (`#857 <https://github.com/agronholm/anyio/issues/857>`_; PR by @11kkw and @agronholm)
- Fixed inconsistency between Trio and asyncio where a TCP stream that previously
  raised a ``BrokenResourceError`` on ``send()`` would still raise
  ``BrokenResourceError`` after the stream was closed on asyncio, but
  ``ClosedResourceError`` on Trio. They now both raise a ``ClosedResourceError`` in this
  scenario. (`#671 <https://github.com/agronholm/anyio/issues/671>`_)

**4.10.0**

- Added the ``feed_data()`` method to the ``BufferedByteReceiveStream`` class, allowing
  users to inject data directly into the buffer
- Added various class methods to wrap existing sockets as listeners or socket streams:

  * ``SocketListener.from_socket()``
  * ``SocketStream.from_socket()``
  * ``UNIXSocketStream.from_socket()``
  * ``UDPSocket.from_socket()``
  * ``ConnectedUDPSocket.from_socket()``
  * ``UNIXDatagramSocket.from_socket()``
  * ``ConnectedUNIXDatagramSocket.from_socket()``
- Added a hierarchy of connectable stream classes for transparently connecting to
  various remote or local endpoints for exchanging bytes or objects
- Added ``BufferedByteStream``, a full-duplex variant of ``BufferedByteReceiveStream``
- Added context manager mix-in classes (``anyio.ContextManagerMixin`` and
  ``anyio.AsyncContextManagerMixin``) to help write classes that embed other context
  managers, particularly cancel scopes or task groups
  (`#905 <https://github.com/agronholm/anyio/pull/905>`_; PR by @agronholm and
  @tapetersen)
- Added the ability to specify the thread name in ``start_blocking_portal()``
  (`#818 <https://github.com/agronholm/anyio/issues/818>`_; PR by @davidbrochart)
- Added ``anyio.notify_closing`` to allow waking ``anyio.wait_readable``
  and ``anyio.wait_writable`` before closing a socket. Among other things,
  this prevents an OSError on the ``ProactorEventLoop``.
  (`#896 <https://github.com/agronholm/anyio/pull/896>`_; PR by @graingert)
- Incorporated several documentation improvements from the EuroPython 2025 sprint
  (special thanks to the sprinters: Emmanuel Okedele, Jan Murre, Euxenia Miruna Goia and
  Christoffer Fjord)
- Added a documentation page explaining why one might want to use AnyIO's APIs instead
  of asyncio's
- Updated the ``to_interpreters`` module to use the public ``concurrent.interpreters``
  API on Python 3.14 or later
- Fixed ``anyio.Path.copy()`` and ``anyio.Path.copy_into()`` failing on Python 3.14.0a7
- Fixed return annotation of ``__aexit__`` on async context managers. CMs which can
  suppress exceptions should return ``bool``, or ``None`` otherwise.
  (`#913 <https://github.com/agronholm/anyio/pull/913>`_; PR by @Enegg)
- Fixed rollover boundary check in ``SpooledTemporaryFile`` so that rollover
  only occurs when the buffer size exceeds ``max_size``
  (`#915 <https://github.com/agronholm/anyio/pull/915>`_; PR by @11kkw)
- Migrated testing and documentation dependencies from extras to dependency groups
- Fixed compatibility of ``anyio.to_interpreter`` with Python 3.14.0b2
  (`#926 <https://github.com/agronholm/anyio/issues/926>`_; PR by @hroncok)
- Fixed ``SyntaxWarning`` on Python 3.14 about ``return`` in ``finally``
  (`#816 <https://github.com/agronholm/anyio/issues/816>`_)
- Fixed RunVar name conflicts. RunVar instances with the same name should not share
  storage (`#880 <https://github.com/agronholm/anyio/issues/880>`_; PR by @vimfu)
- Renamed the ``BrokenWorkerIntepreter`` exception to ``BrokenWorkerInterpreter``.
  The old name is available as a deprecated alias.
  (`#938 <https://github.com/agronholm/anyio/pull/938>`_; PR by @ayussh-verma)
- Fixed an edge case in ``CapacityLimiter`` on asyncio where a task, waiting to acquire
  a limiter gets cancelled and is subsequently granted a token from the limiter, but
  before the cancellation is delivered, and then fails to notify the next waiting task
  (`#947 <https://github.com/agronholm/anyio/issues/947>`_)

**4.9.0**

- Added async support for temporary file handling
  (`#344 <https://github.com/agronholm/anyio/issues/344>`_; PR by @11kkw)
- Added 4 new fixtures for the AnyIO ``pytest`` plugin:

  * ``free_tcp_port_factory``: session scoped fixture returning a callable that
    generates unused TCP port numbers
  * ``free_udp_port_factory``: session scoped fixture returning a callable that
    generates unused UDP port numbers
  * ``free_tcp_port``: function scoped fixture that invokes the
    ``free_tcp_port_factory`` fixture to generate a free TCP port number
  * ``free_udp_port``: function scoped fixture that invokes the
    ``free_udp_port_factory`` fixture to generate a free UDP port number
- Added ``stdin`` argument to ``anyio.run_process()`` akin to what
  ``anyio.open_process()``, ``asyncio.create_subprocess_…()``, ``trio.run_process()``,
  and ``subprocess.run()`` already accept (PR by @jmehnle)
- Added the ``info`` property to ``anyio.Path`` on Python 3.14
- Changed ``anyio.getaddrinfo()`` to ignore (invalid) IPv6 name resolution results when
  IPv6 support is disabled in Python
- Changed ``EndOfStream`` raised from ``MemoryObjectReceiveStream.receive()`` to leave
  out the ``AttributeError`` from the exception chain which was merely an implementation
  detail and caused some confusion
- Fixed traceback formatting growing quadratically with level of ``TaskGroup``
  nesting on asyncio due to exception chaining when raising ``ExceptionGroups``
  in ``TaskGroup.__aexit__``
  (`#863 <https://github.com/agronholm/anyio/issues/863>`_; PR by @tapetersen)
- Fixed ``anyio.Path.iterdir()`` making a blocking call in Python 3.13
  (`#873 <https://github.com/agronholm/anyio/issues/873>`_; PR by @cbornet and
  @agronholm)
- Fixed ``connect_tcp()`` producing cyclic references in tracebacks when raising
  exceptions (`#809 <https://github.com/agronholm/anyio/pull/809>`_; PR by @graingert)
- Fixed ``anyio.to_thread.run_sync()`` needlessly holding on to references of the
  context, function, arguments and others until the next work item on asyncio
  (PR by @Wankupi)

**4.8.0**

- Added **experimental** support for running functions in subinterpreters on Python
  3.13 and later
- Added support for the ``copy()``, ``copy_into()``, ``move()`` and ``move_into()``
  methods in ``anyio.Path``, available in Python 3.14
- Changed ``TaskGroup`` on asyncio to always spawn tasks non-eagerly, even if using a
  task factory created via ``asyncio.create_eager_task_factory()``, to preserve expected
  Trio-like task scheduling semantics (PR by @agronholm and @graingert)
- Configure ``SO_RCVBUF``, ``SO_SNDBUF`` and ``TCP_NODELAY`` on the selector
  thread waker socket pair (this should improve the performance of ``wait_readable()``)
  and ``wait_writable()`` when using the ``ProactorEventLoop``
  (`#836 <https://github.com/agronholm/anyio/pull/836>`_; PR by @graingert)
- Fixed ``AssertionError`` when using ``nest-asyncio``
  (`#840 <https://github.com/agronholm/anyio/issues/840>`_)
- Fixed return type annotation of various context managers' ``__exit__`` method
  (`#847 <https://github.com/agronholm/anyio/issues/847>`_; PR by @Enegg)

**4.7.0**

- Updated ``TaskGroup`` to work with asyncio's eager task factories
  (`#764 <https://github.com/agronholm/anyio/issues/764>`_)
- Added the ``wait_readable()`` and ``wait_writable()`` functions which will accept
  an object with a ``.fileno()`` method or an integer handle, and deprecated
  their now obsolete versions (``wait_socket_readable()`` and
  ``wait_socket_writable()``) (PR by @davidbrochart)
- Changed ``EventAdapter`` (an ``Event`` with no bound async backend) to allow ``set()``
  to work even before an async backend is bound to it
  (`#819 <https://github.com/agronholm/anyio/issues/819>`_)
- Added support for ``wait_readable()`` and ``wait_writable()`` on ``ProactorEventLoop``
  (used on asyncio + Windows by default)
- Fixed a misleading ``ValueError`` in the context of DNS failures
  (`#815 <https://github.com/agronholm/anyio/issues/815>`_; PR by @graingert)
- Fixed the return type annotations of ``readinto()`` and ``readinto1()`` methods in the
  ``anyio.AsyncFile`` class
  (`#825 <https://github.com/agronholm/anyio/issues/825>`_)
- Fixed ``TaskInfo.has_pending_cancellation()`` on asyncio returning false positives in
  cleanup code on Python >= 3.11
  (`#832 <https://github.com/agronholm/anyio/issues/832>`_; PR by @gschaffner)
- Fixed cancelled cancel scopes on asyncio calling ``asyncio.Task.uncancel`` when
  propagating a ``CancelledError`` on exit to a cancelled parent scope
  (`#790 <https://github.com/agronholm/anyio/pull/790>`_; PR by @gschaffner)

**4.6.2**

- Fixed regression caused by (`#807 <https://github.com/agronholm/anyio/pull/807>`_)
  that prevented the use of parametrized async fixtures

**4.6.1**

This release contains all the changes from both v4.5.1 and v4.6.0, plus:

- Fixed TaskGroup and CancelScope producing cyclic references in tracebacks
  when raising exceptions (`#806 <https://github.com/agronholm/anyio/pull/806>`_)
  (PR by @graingert)

**4.6.0**

This release is the successor to v4.5.0 with Python 3.8 support dropped, and does not
contain the changes from v4.5.1.

- Dropped support for Python 3.8
  (as `#698 <https://github.com/agronholm/anyio/issues/698>`_ cannot be resolved
  without cancel message support)
- Fixed 100% CPU use on asyncio while waiting for an exiting task group to finish while
  said task group is within a cancelled cancel scope
  (`#695 <https://github.com/agronholm/anyio/issues/695>`_)
- Fixed cancel scopes on asyncio not propagating ``CancelledError`` on exit when the
  enclosing cancel scope has been effectively cancelled
  (`#698 <https://github.com/agronholm/anyio/issues/698>`_)
- Fixed asyncio task groups not yielding control to the event loop at exit if there were
  no child tasks to wait on
- Fixed inconsistent task uncancellation with asyncio cancel scopes belonging to a
  task group when said task group has child tasks running

**4.5.1**

As Python 3.8 support was dropped in v4.6.0, this interim release was created to bring a
regression fix to Python 3.8, and adds a few other fixes also present in v4.6.1.

- Fixed acquiring a lock twice in the same task on asyncio hanging instead of raising a
  ``RuntimeError`` (`#798 <https://github.com/agronholm/anyio/issues/798>`_)
- Fixed an async fixture's ``self`` being different than the test's ``self`` in
  class-based tests (`#633 <https://github.com/agronholm/anyio/issues/633>`_)
  (PR by @agronholm and @graingert)
- Fixed ``TypeError`` with ``TLSStream`` on Windows when a certificate verification
  error occurs when using a `truststore <https://github.com/sethmlarson/truststore>`_
  SSL certificate (`#795 <https://github.com/agronholm/anyio/issues/795>`_)
- Corrected documentation on ``anyio.Path`` regarding the limitations imposed by the
  current Python version on several of its methods, and made the ``is_junction`` method
  unavailable on Python versions earlier than 3.12
  (`#794 <https://github.com/agronholm/anyio/issues/794>`_)

**4.5.0**

- Improved the performance of ``anyio.Lock`` and ``anyio.Semaphore`` on asyncio (even up
  to 50 %)
- Added the ``fast_acquire`` parameter to ``anyio.Lock`` and ``anyio.Semaphore`` to
  further boost performance at the expense of safety (``acquire()`` will not yield
  control back if there is no contention)
- Added support for the ``from_uri()``, ``full_match()``, ``parser`` methods/properties
  in ``anyio.Path``, newly added in Python 3.13
  (`#737 <https://github.com/agronholm/anyio/issues/737>`_)
- Added support for more keyword arguments for ``run_process()`` and ``open_process()``:
  ``startupinfo``, ``creationflags``, ``pass_fds``, ``user``, ``group``,
  ``extra_groups`` and ``umask``
  (`#742 <https://github.com/agronholm/anyio/issues/742>`_)
- Improved the type annotations and support for ``PathLike`` in ``run_process()`` and
  ``open_process()`` to allow for path-like arguments, just like ``subprocess.Popen``
- Changed the ``ResourceWarning`` from an unclosed memory object stream to include its
  address for easier identification
- Changed ``start_blocking_portal()`` to always use daemonic threads, to accommodate the
  "loitering event loop" use case
- Bumped the minimum version of Trio to v0.26.1
- Fixed ``__repr__()`` of ``MemoryObjectItemReceiver``, when ``item`` is not defined
  (`#767 <https://github.com/agronholm/anyio/pull/767>`_; PR by @Danipulok)
- Fixed ``to_process.run_sync()`` failing to initialize if ``__main__.__file__`` pointed
  to a file in a nonexistent directory
  (`#696 <https://github.com/agronholm/anyio/issues/696>`_)
- Fixed ``AssertionError: feed_data after feed_eof`` on asyncio when a subprocess is
  closed early, before its output has been read
  (`#490 <https://github.com/agronholm/anyio/issues/490>`_)
- Fixed ``TaskInfo.has_pending_cancellation()`` on asyncio not respecting shielded
  scopes (`#771 <https://github.com/agronholm/anyio/issues/771>`_; PR by @gschaffner)
- Fixed ``SocketStream.receive()`` returning ``bytearray`` instead of ``bytes`` when
  using asyncio with ``ProactorEventLoop`` (Windows)
  (`#776 <https://github.com/agronholm/anyio/issues/776>`_)
- Fixed quitting the debugger in a pytest test session while in an active task group
  failing the test instead of exiting the test session (because the exit exception
  arrives in an exception group)
- Fixed support for Linux abstract namespaces in UNIX sockets that was broken in v4.2
  (`#781 <https://github.com/agronholm/anyio/issues/781>`_; PR by @tapetersen)
- Fixed ``KeyboardInterrupt`` (ctrl+c) hanging the asyncio pytest runner

**4.4.0**

- Added the ``BlockingPortalProvider`` class to aid with constructing synchronous
  counterparts to asynchronous interfaces that would otherwise require multiple blocking
  portals
- Added ``__slots__`` to ``AsyncResource`` so that child classes can use ``__slots__``
  (`#733 <https://github.com/agronholm/anyio/pull/733>`_; PR by Justin Su)
- Added the ``TaskInfo.has_pending_cancellation()`` method
- Fixed erroneous ``RuntimeError: called 'started' twice on the same task status``
  when cancelling a task in a TaskGroup created with the ``start()`` method before
  the first checkpoint is reached after calling ``task_status.started()``
  (`#706 <https://github.com/agronholm/anyio/issues/706>`_; PR by Dominik Schwabe)
- Fixed two bugs with ``TaskGroup.start()`` on asyncio:

  * Fixed erroneous ``RuntimeError: called 'started' twice on the same task status``
    when cancelling a task in a TaskGroup created with the ``start()`` method before
    the first checkpoint is reached after calling ``task_status.started()``
    (`#706 <https://github.com/agronholm/anyio/issues/706>`_; PR by Dominik Schwabe)
  * Fixed the entire task group being cancelled if a ``TaskGroup.start()`` call gets
    cancelled (`#685 <https://github.com/agronholm/anyio/issues/685>`_,
    `#710 <https://github.com/agronholm/anyio/issues/710>`_)
- Fixed a race condition that caused crashes when multiple event loops of the same
  backend were running in separate threads and simultaneously attempted to use AnyIO for
  their first time (`#425 <https://github.com/agronholm/anyio/issues/425>`_; PR by David
  Jiricek and Ganden Schaffner)
- Fixed cancellation delivery on asyncio incrementing the wrong cancel scope's
  cancellation counter when cascading a cancel operation to a child scope, thus failing
  to uncancel the host task (`#716 <https://github.com/agronholm/anyio/issues/716>`_)
- Fixed erroneous ``TypedAttributeLookupError`` if a typed attribute getter raises
  ``KeyError``
- Fixed the asyncio backend not respecting the ``PYTHONASYNCIODEBUG`` environment
  variable when setting the ``debug`` flag in ``anyio.run()``
- Fixed ``SocketStream.receive()`` not detecting EOF on asyncio if there is also data in
  the read buffer (`#701 <https://github.com/agronholm/anyio/issues/701>`_)
- Fixed ``MemoryObjectStream`` dropping an item if the item is delivered to a recipient
  that is waiting to receive an item but has a cancellation pending
  (`#728 <https://github.com/agronholm/anyio/issues/728>`_)
- Emit a ``ResourceWarning`` for ``MemoryObjectReceiveStream`` and
  ``MemoryObjectSendStream`` that were garbage collected without being closed (PR by
  Andrey Kazantcev)
- Fixed ``MemoryObjectSendStream.send()`` not raising ``BrokenResourceError`` when the
  last corresponding ``MemoryObjectReceiveStream`` is closed while waiting to send a
  falsey item (`#731 <https://github.com/agronholm/anyio/issues/731>`_; PR by Ganden
  Schaffner)

**4.3.0**

- Added support for the Python 3.12 ``walk_up`` keyword argument in
  ``anyio.Path.relative_to()`` (PR by Colin Taylor)
- Fixed passing ``total_tokens`` to ``anyio.CapacityLimiter()`` as a keyword argument
  not working on the ``trio`` backend
  (`#515 <https://github.com/agronholm/anyio/issues/515>`_)
- Fixed ``Process.aclose()`` not performing the minimum level of necessary cleanup when
  cancelled. Previously:

  - Cancellation of ``Process.aclose()`` could leak an orphan process
  - Cancellation of ``run_process()`` could very briefly leak an orphan process.
  - Cancellation of ``Process.aclose()`` or ``run_process()`` on Trio could leave
    standard streams unclosed

  (PR by Ganden Schaffner)
- Fixed ``Process.stdin.aclose()``, ``Process.stdout.aclose()``, and
  ``Process.stderr.aclose()`` not including a checkpoint on asyncio (PR by Ganden
  Schaffner)
- Fixed documentation on how to provide your own typed attributes

**4.2.0**

- Add support for ``byte``-based paths in ``connect_unix``, ``create_unix_listeners``,
  ``create_unix_datagram_socket``, and ``create_connected_unix_datagram_socket``. (PR by
  Lura Skye)
- Enabled the ``Event`` and ``CapacityLimiter`` classes to be instantiated outside an
  event loop thread
- Broadly improved/fixed the type annotations. Among other things, many functions and
  methods that take variadic positional arguments now make use of PEP 646
  ``TypeVarTuple`` to allow the positional arguments to be validated by static type
  checkers. These changes affected numerous methods and functions, including:

  * ``anyio.run()``
  * ``TaskGroup.start_soon()``
  * ``anyio.from_thread.run()``
  * ``anyio.from_thread.run_sync()``
  * ``anyio.to_thread.run_sync()``
  * ``anyio.to_process.run_sync()``
  * ``BlockingPortal.call()``
  * ``BlockingPortal.start_task_soon()``
  * ``BlockingPortal.start_task()``

  (also resolves `#560 <https://github.com/agronholm/anyio/issues/560>`_)
- Fixed various type annotations of ``anyio.Path`` to match Typeshed:

  * ``anyio.Path.__lt__()``
  * ``anyio.Path.__le__()``
  * ``anyio.Path.__gt__()``
  * ``anyio.Path.__ge__()``
  * ``anyio.Path.__truediv__()``
  * ``anyio.Path.__rtruediv__()``
  * ``anyio.Path.hardlink_to()``
  * ``anyio.Path.samefile()``
  * ``anyio.Path.symlink_to()``
  * ``anyio.Path.with_segments()``

  (PR by Ganden Schaffner)
- Fixed adjusting the total number of tokens in a ``CapacityLimiter`` on asyncio failing
  to wake up tasks waiting to acquire the limiter in certain edge cases (fixed with help
  from Egor Blagov)
- Fixed ``loop_factory`` and ``use_uvloop`` options not being used on the asyncio
  backend (`#643 <https://github.com/agronholm/anyio/issues/643>`_)
- Fixed cancellation propagating on asyncio from a task group to child tasks if the task
  hosting the task group is in a shielded cancel scope
  (`#642 <https://github.com/agronholm/anyio/issues/642>`_)

**4.1.0**

- Adapted to API changes made in Trio v0.23:

  - Call ``trio.to_thread.run_sync()`` using the ``abandon_on_cancel`` keyword argument
    instead of ``cancellable``
  - Removed a checkpoint when exiting a task group
  - Renamed the ``cancellable`` argument in ``anyio.to_thread.run_sync()`` to
    ``abandon_on_cancel`` (and deprecated the old parameter name)
  - Bumped minimum version of Trio to v0.23
- Added support for voluntary thread cancellation via
  ``anyio.from_thread.check_cancelled()``
- Bumped minimum version of trio to v0.23
- Exposed the ``ResourceGuard`` class in the public API
  (`#627 <https://github.com/agronholm/anyio/issues/627>`_)
- Fixed ``RuntimeError: Runner is closed`` when running higher-scoped async generator
  fixtures in some cases (`#619 <https://github.com/agronholm/anyio/issues/619>`_)
- Fixed discrepancy between ``asyncio`` and ``trio`` where reraising a cancellation
  exception in an ``except*`` block would incorrectly bubble out of its cancel scope
  (`#634 <https://github.com/agronholm/anyio/issues/634>`_)

**4.0.0**

- **BACKWARDS INCOMPATIBLE** Replaced AnyIO's own ``ExceptionGroup`` class with the PEP
  654 ``BaseExceptionGroup`` and ``ExceptionGroup``
- **BACKWARDS INCOMPATIBLE** Changes to cancellation semantics:

  - Any exceptions raising out of a task groups are now nested inside an
    ``ExceptionGroup`` (or ``BaseExceptionGroup`` if one or more ``BaseException`` were
    included)
  - Fixed task group not raising a cancellation exception on asyncio at exit if no child
    tasks were spawned and an outer cancellation scope had been cancelled before
  - Ensured that exiting a ``TaskGroup`` always hits a yield point, regardless of
    whether there are running child tasks to be waited on
  - On asyncio, cancel scopes will defer cancelling tasks that are scheduled to resume
    with a finished future
  - On asyncio and Python 3.9/3.10, cancel scopes now only suppress cancellation
    exceptions if the cancel message matches the scope
  - Task groups on all backends now raise a single cancellation exception when an outer
    cancel scope is cancelled, and no exceptions other than cancellation exceptions are
    raised in the group
- **BACKWARDS INCOMPATIBLE** Changes the pytest plugin to run all tests and fixtures in
  the same task, allowing fixtures to set context variables for tests and other fixtures
- **BACKWARDS INCOMPATIBLE** Changed ``anyio.Path.relative_to()`` and
  ``anyio.Path.is_relative_to()`` to only accept one argument, as passing multiple
  arguments is deprecated as of Python 3.12
- **BACKWARDS INCOMPATIBLE** Dropped support for spawning tasks from old-style coroutine
  functions (``@asyncio.coroutine``)
- **BACKWARDS INCOMPATIBLE** The ``policy`` option on the ``asyncio`` backend was
  changed to ``loop_factory`` to accommodate ``asyncio.Runner``
- Changed ``anyio.run()`` to use ``asyncio.Runner`` (or a back-ported version of it on
  Pythons older than 3.11) on the ``asyncio`` backend
- Dropped support for Python 3.7
- Added support for Python 3.12
- Bumped minimum version of trio to v0.22
- Added the ``anyio.Path.is_junction()`` and ``anyio.Path.walk()`` methods
- Added ``create_unix_datagram_socket`` and ``create_connected_unix_datagram_socket`` to
  create UNIX datagram sockets (PR by Jean Hominal)
- Fixed ``from_thread.run`` and ``from_thread.run_sync`` not setting sniffio on asyncio.
  As a result:

  - Fixed ``from_thread.run_sync`` failing when used to call sniffio-dependent functions
    on asyncio
  - Fixed ``from_thread.run`` failing when used to call sniffio-dependent functions on
    asyncio from a thread running trio or curio
  - Fixed deadlock when using ``from_thread.start_blocking_portal(backend="asyncio")``
    in a thread running trio or curio (PR by Ganden Schaffner)
- Improved type annotations:

  - The ``item_type`` argument of ``create_memory_object_stream`` was deprecated.
    To indicate the item type handled by the stream, use
    ``create_memory_object_stream[T_Item]()`` instead. Type checking should no longer
    fail when annotating memory object streams with uninstantiable item types (PR by
    Ganden Schaffner)
- Added the ``CancelScope.cancelled_caught`` property which tells users if the cancel
  scope suppressed a cancellation exception
- Fixed ``fail_after()`` raising an unwarranted ``TimeoutError`` when the cancel scope
  was cancelled before reaching its deadline
- Fixed ``MemoryObjectReceiveStream.receive()`` causing the receiving task on asyncio to
  remain in a cancelled state if the operation was cancelled after an item was queued to
  be received by the task (but before the task could actually receive the item)
- Fixed ``TaskGroup.start()`` on asyncio not responding to cancellation from the outside
- Fixed tasks started from ``BlockingPortal`` not notifying synchronous listeners
  (``concurrent.futures.wait()``) when they're cancelled
- Removed unnecessary extra waiting cycle in ``Event.wait()`` on asyncio in the case
  where the event was not yet set
- Fixed processes spawned by ``anyio.to_process()`` being "lost" as unusable to the
  process pool when processes that have idled over 5 minutes are pruned at part of the
  ``to_process.run_sync()`` call, leading to increased memory consumption
  (PR by Anael Gorfinkel)

Changes since 4.0.0rc1:

- Fixed the type annotation of ``TaskGroup.start_soon()`` to accept any awaitables
  (already in v3.7.0 but was missing from 4.0.0rc1)
- Changed ``CancelScope`` to also consider the cancellation count (in addition to the
  cancel message) on asyncio to determine if a cancellation exception should be
  swallowed on scope exit, to combat issues where third party libraries catch the
  ``CancelledError`` and raise another, thus erasing the original cancel message
- Worked around a `CPython bug <https://github.com/python/cpython/issues/108668>`_ that
  caused ``TLSListener.handle_handshake_error()`` on asyncio to log ``"NoneType: None"``
  instead of the error (PR by Ganden Schaffner)
- Re-added the ``item_type`` argument to ``create_memory_object_stream()`` (but using it
  raises a deprecation warning and does nothing with regards to the static types of the
  returned streams)
- Fixed processes spawned by ``anyio.to_process()`` being "lost" as unusable to the
  process pool when processes that have idled over 5 minutes are pruned at part of the
  ``to_process.run_sync()`` call, leading to increased memory consumption
  (PR by Anael Gorfinkel)

**3.7.1**

- Fixed sending large buffers via UNIX stream sockets on asyncio
- Fixed several minor documentation issues (broken links to classes, missing classes or
  attributes)

**3.7.0**

- Dropped support for Python 3.6
- Improved type annotations:

  - Several functions and methods that were previously annotated as accepting
    ``Coroutine[Any, Any, Any]`` as the return type of the callable have been amended to
    accept ``Awaitable[Any]`` instead, to allow a slightly broader set of coroutine-like
    inputs, like ``async_generator_asend`` objects returned from the ``asend()`` method
    of async generators, and to match the ``trio`` annotations:

    - ``anyio.run()``
    - ``anyio.from_thread.run()``
    - ``TaskGroup.start_soon()``
    - ``TaskGroup.start()``
    - ``BlockingPortal.call()``
    - ``BlockingPortal.start_task_soon()``
    - ``BlockingPortal.start_task()``

    Note that this change involved only changing the type annotations; run-time
    functionality was not altered.

  - The ``TaskStatus`` class is now a generic protocol, and should be parametrized to
    indicate the type of the value passed to ``task_status.started()``
  - The ``Listener`` class is now covariant in its stream type
  - ``create_memory_object_stream()`` now allows passing only ``item_type``
  - Object receive streams are now covariant and object send streams are correspondingly
    contravariant
- Changed ``TLSAttribute.shared_ciphers`` to match the documented semantics of
  ``SSLSocket.shared_ciphers`` of always returning ``None`` for client-side streams
- Fixed ``CapacityLimiter`` on the asyncio backend to order waiting tasks in the FIFO
  order (instead of LIFO) (PR by Conor Stevenson)
- Fixed ``CancelScope.cancel()`` not working on asyncio if called before entering the
  scope
- Fixed ``open_signal_receiver()`` inconsistently yielding integers instead of
  ``signal.Signals`` instances on the ``trio`` backend
- Fixed ``to_thread.run_sync()`` hanging on asyncio if the target callable raises
  ``StopIteration``
- Fixed ``start_blocking_portal()`` raising an unwarranted
  ``RuntimeError: This portal is not running`` if a task raises an exception that causes
  the event loop to be closed
- Fixed ``current_effective_deadline()`` not returning ``-inf`` on asyncio when the
  currently active cancel scope has been cancelled (PR by Ganden Schaffner)
- Fixed the ``OP_IGNORE_UNEXPECTED_EOF`` flag in an SSL context created by default in
  ``TLSStream.wrap()`` being inadvertently set on Python 3.11.3 and 3.10.11
- Fixed ``CancelScope`` to properly handle asyncio task uncancellation on Python 3.11
  (PR by Nikolay Bryskin)
- Fixed ``OSError`` when trying to use ``create_tcp_listener()`` to bind to a link-local
  IPv6 address (and worked around related bugs in ``uvloop``)
- Worked around a `PyPy bug <https://foss.heptapod.net/pypy/pypy/-/issues/3938>`_
  when using ``anyio.getaddrinfo()`` with for IPv6 link-local addresses containing
  interface names

**3.6.2**

- Pinned Trio to < 0.22 to avoid incompatibility with AnyIO's ``ExceptionGroup`` class
  causing ``AttributeError: 'NonBaseMultiError' object has no attribute '_exceptions'``

**3.6.1**

- Fixed exception handler in the asyncio test runner not properly handling a context
  that does not contain the ``exception`` key

**3.6.0**

- Fixed ``TypeError`` in ``get_current_task()`` on asyncio when using a custom ``Task``
  factory
- Updated type annotations on ``run_process()`` and ``open_process()``:

  * ``command`` now accepts accepts bytes and sequences of bytes
  * ``stdin``, ``stdout`` and ``stderr`` now accept file-like objects
    (PR by John T. Wodder II)
- Changed the pytest plugin to run both the setup and teardown phases of asynchronous
  generator fixtures within a single task to enable use cases such as cancel scopes and
  task groups where a context manager straddles the ``yield``

**3.5.0**

- Added ``start_new_session`` keyword argument to ``run_process()`` and
  ``open_process()`` (PR by Jordan Speicher)
- Fixed deadlock in synchronization primitives on asyncio which can happen if a task
  acquiring a primitive is hit with a native (not AnyIO) cancellation with just the
  right timing, leaving the next acquiring task waiting forever
  (`#398 <https://github.com/agronholm/anyio/issues/398>`_)
- Added workaround for bpo-46313_ to enable compatibility with OpenSSL 3.0

.. _bpo-46313: https://bugs.python.org/issue46313

**3.4.0**

- Added context propagation to/from worker threads in ``to_thread.run_sync()``,
  ``from_thread.run()`` and ``from_thread.run_sync()``
  (`#363 <https://github.com/agronholm/anyio/issues/363>`_; partially based on a PR by
  Sebastián Ramírez)

  **NOTE**: Requires Python 3.7 to work properly on asyncio!
- Fixed race condition in ``Lock`` and ``Semaphore`` classes when a task waiting on
  ``acquire()`` is cancelled while another task is waiting to acquire the same primitive
  (`#387 <https://github.com/agronholm/anyio/issues/387>`_)
- Fixed async context manager's ``__aexit__()`` method not being called in
  ``BlockingPortal.wrap_async_context_manager()`` if the host task is cancelled
  (`#381 <https://github.com/agronholm/anyio/issues/381>`_; PR by Jonathan Slenders)
- Fixed worker threads being marked as being event loop threads in sniffio
- Fixed task parent ID not getting set to the correct value on asyncio
- Enabled the test suite to run without IPv6 support, trio or pytest plugin autoloading

**3.3.4**

- Fixed ``BrokenResourceError`` instead of ``EndOfStream`` being raised in ``TLSStream``
  when the peer abruptly closes the connection while ``TLSStream`` is receiving data
  with ``standard_compatible=False`` set

**3.3.3**

- Fixed UNIX socket listener not setting accepted sockets to non-blocking mode on
  asyncio
- Changed unconnected UDP sockets to be always bound to a local port (on "any"
  interface) to avoid errors on asyncio + Windows

**3.3.2**

- Fixed cancellation problem on asyncio where level-triggered cancellation for **all**
  parent cancel scopes would not resume after exiting a shielded nested scope
  (`#370 <https://github.com/agronholm/anyio/issues/370>`_)

**3.3.1**

- Added missing documentation for the ``ExceptionGroup.exceptions`` attribute
- Changed the asyncio test runner not to use uvloop by default (to match the behavior of
  ``anyio.run()``)
- Fixed ``RuntimeError`` on asyncio when a ``CancelledError`` is raised from a task
  spawned through a ``BlockingPortal``
  (`#357 <https://github.com/agronholm/anyio/issues/357>`_)
- Fixed asyncio warning about a ``Future`` with an exception that was never retrieved
  which happened when a socket was already written to but the peer abruptly closed the
  connection

**3.3.0**

- Added asynchronous ``Path`` class
- Added the ``wrap_file()`` function for wrapping existing files as asynchronous file
  objects
- Relaxed the type of the ``path`` initializer argument to ``FileReadStream`` and
  ``FileWriteStream`` so they accept any path-like object (including the new
  asynchronous ``Path`` class)
- Dropped unnecessary dependency on the ``async_generator`` library
- Changed the generics in ``AsyncFile`` so that the methods correctly return either
  ``str`` or ``bytes`` based on the argument to ``open_file()``
- Fixed an asyncio bug where under certain circumstances, a stopping worker thread would
  still accept new assignments, leading to a hang

**3.2.1**

- Fixed idle thread pruning on asyncio sometimes causing an expired worker thread to be
  assigned a task

**3.2.0**

- Added Python 3.10 compatibility
- Added the ability to close memory object streams synchronously (including support for
  use as a synchronous context manager)
- Changed the default value of the ``use_uvloop`` asyncio backend option to ``False`` to
  prevent unsafe event loop policy changes in different threads
- Fixed ``to_thread.run_sync()`` hanging on the second call on asyncio when used with
  ``loop.run_until_complete()``
- Fixed ``to_thread.run_sync()`` prematurely marking a worker thread inactive when a
  task await on the result is cancelled
- Fixed ``ResourceWarning`` about an unclosed socket when UNIX socket connect fails on
  asyncio
- Fixed the type annotation of ``open_signal_receiver()`` as a synchronous context
  manager
- Fixed the type annotation of ``DeprecatedAwaitable(|List|Float).__await__`` to match
  the ``typing.Awaitable`` protocol

**3.1.0**

- Added ``env`` and ``cwd`` keyword arguments to ``run_process()`` and ``open_process``.
- Added support for mutation of ``CancelScope.shield`` (PR by John Belmonte)
- Added the ``sleep_forever()`` and ``sleep_until()`` functions
- Changed asyncio task groups so that if the host and child tasks have only raised
  ``CancelledErrors``, just one ``CancelledError`` will now be raised instead of an
  ``ExceptionGroup``, allowing asyncio to ignore it when it propagates out of the task
- Changed task names to be converted to ``str`` early on asyncio (PR by Thomas Grainger)
- Fixed ``sniffio._impl.AsyncLibraryNotFoundError: unknown async library, or not in
  async context`` on asyncio and Python 3.6 when ``to_thread.run_sync()`` is used from
  ``loop.run_until_complete()``
- Fixed odd ``ExceptionGroup: 0 exceptions were raised in the task group`` appearing
  under certain circumstances on asyncio
- Fixed ``wait_all_tasks_blocked()`` returning prematurely on asyncio when a previously
  blocked task is cancelled (PR by Thomas Grainger)
- Fixed declared return type of ``TaskGroup.start()`` (it was declared as ``None``, but
  anything can be returned from it)
- Fixed ``TextStream.extra_attributes`` raising ``AttributeError`` (PR by Thomas
  Grainger)
- Fixed ``await maybe_async(current_task())`` returning ``None`` (PR by Thomas Grainger)
- Fixed: ``pickle.dumps(current_task())`` now correctly raises ``TypeError`` instead of
  pickling to ``None`` (PR by Thomas Grainger)
- Fixed return type annotation of ``Event.wait()`` (``bool`` → ``None``) (PR by Thomas
  Grainger)
- Fixed return type annotation of ``RunVar.get()`` to return either the type of the
  default value or the type of the contained value (PR by Thomas Grainger)
- Fixed a deprecation warning message to refer to ``maybe_async()`` and not
  ``maybe_awaitable()`` (PR by Thomas Grainger)
- Filled in argument and return types for all functions and methods previously missing
  them (PR by Thomas Grainger)

**3.0.1**

- Fixed ``to_thread.run_sync()`` raising ``RuntimeError`` on asyncio when no "root" task
  could be found for setting up a cleanup callback. This was a problem at least on
  Tornado and possibly also Twisted in asyncio compatibility mode. The life of worker
  threads is now bound to the the host task of the topmost cancel scope hierarchy
  starting from the current one, or if no cancel scope is active, the current task.

**3.0.0**

- Curio support has been dropped (see the :doc:`FAQ <faq>` as for why)
- API changes:

  * **BACKWARDS INCOMPATIBLE** Submodules under ``anyio.abc.`` have been made private
    (use only ``anyio.abc`` from now on).
  * **BACKWARDS INCOMPATIBLE** The following method was previously a coroutine method
    and has been converted into a synchronous one:

    * ``MemoryObjectReceiveStream.receive_nowait()``

  * The following functions and methods are no longer asynchronous but can still be
    awaited on (doing so will emit a deprecation warning):

    * ``current_time()``
    * ``current_effective_deadline()``
    * ``get_current_task()``
    * ``get_running_tasks()``
    * ``CancelScope.cancel()``
    * ``CapacityLimiter.acquire_nowait()``
    * ``CapacityLimiter.acquire_on_behalf_of_nowait()``
    * ``Condition.release()``
    * ``Event.set()``
    * ``Lock.release()``
    * ``MemoryObjectSendStream.send_nowait()``
    * ``Semaphore.release()``
  * The following functions now return synchronous context managers instead of
    asynchronous context managers (and emit deprecation warnings if used as async
    context managers):

    * ``fail_after()``
    * ``move_on_after()``
    * ``open_cancel_scope()`` (now just ``CancelScope()``; see below)
    * ``open_signal_receiver()``

  * The following functions and methods have been renamed/moved (will now emit
    deprecation warnings when you use them by their old names):

    * ``create_blocking_portal()`` → ``anyio.from_thread.BlockingPortal()``
    * ``create_capacity_limiter()`` → ``anyio.CapacityLimiter()``
    * ``create_event()`` → ``anyio.Event()``
    * ``create_lock()`` → ``anyio.Lock()``
    * ``create_condition()`` → ``anyio.Condition()``
    * ``create_semaphore()`` → ``anyio.Semaphore()``
    * ``current_default_worker_thread_limiter()`` →
      ``anyio.to_thread.current_default_thread_limiter()``
    * ``open_cancel_scope()`` → ``anyio.CancelScope()``
    * ``run_sync_in_worker_thread()`` → ``anyio.to_thread.run_sync()``
    * ``run_async_from_thread()`` → ``anyio.from_thread.run()``
    * ``run_sync_from_thread()`` → ``anyio.from_thread.run_sync()``
    * ``BlockingPortal.spawn_task`` → ``BlockingPortal.start_task_soon``
    * ``CapacityLimiter.set_total_tokens()`` → ``limiter.total_tokens = ...``
    * ``TaskGroup.spawn()`` → ``TaskGroup.start_soon()``

  * **BACKWARDS INCOMPATIBLE** ``start_blocking_portal()`` must now be used as a context
    manager (it no longer returns a BlockingPortal, but a context manager that yields
    one)
  * **BACKWARDS INCOMPATIBLE** The ``BlockingPortal.stop_from_external_thread()`` method
    (use ``portal.call(portal.stop)`` instead now)
  * **BACKWARDS INCOMPATIBLE** The ``SocketStream`` and ``SocketListener`` classes were
    made non-generic
  * Made all non-frozen dataclasses hashable with ``eq=False``
  * Removed ``__slots__`` from ``BlockingPortal``

  See the :doc:`migration documentation <migration>` for instructions on how to deal
  with these changes.
- Improvements to running synchronous code:

  * Added the ``run_sync_from_thread()`` function
  * Added the ``run_sync_in_process()`` function for running code in worker processes
    (big thanks to Richard Sheridan for his help on this one!)
- Improvements to sockets and streaming:

  * Added the ``UNIXSocketStream`` class which is capable of sending and receiving file
    descriptors
  * Added the ``FileReadStream`` and ``FileWriteStream`` classes
  * ``create_unix_listener()`` now removes any existing socket at the given path before
    proceeding (instead of raising ``OSError: Address already in use``)
- Improvements to task groups and cancellation:

  * Added the ``TaskGroup.start()`` method and a corresponding
    ``BlockingPortal.start_task()`` method
  * Added the ``name`` argument to ``BlockingPortal.start_task_soon()``
    (renamed from ``BlockingPortal.spawn_task()``)
  * Changed ``CancelScope.deadline`` to be writable
  * Added the following functions in the ``anyio.lowlevel`` module:

    * ``checkpoint()``
    * ``checkpoint_if_cancelled()``
    * ``cancel_shielded_checkpoint()``
- Improvements and changes to synchronization primitives:

  * Added the ``Lock.acquire_nowait()``, ``Condition.acquire_nowait()`` and
    ``Semaphore.acquire_nowait()`` methods
  * Added the ``statistics()`` method to ``Event``, ``Lock``, ``Condition``, ``Semaphore``,
    ``CapacityLimiter``, ``MemoryObjectReceiveStream`` and ``MemoryObjectSendStream``
  * ``Lock`` and ``Condition`` can now only be released by the task that acquired them.
    This behavior is now consistent on all backends whereas previously only Trio
    enforced this.
  * The ``CapacityLimiter.total_tokens`` property is now writable and
    ``CapacityLimiter.set_total_tokens()`` has been deprecated
  * Added the ``max_value`` property to ``Semaphore``
- Asyncio specific improvements (big thanks to Thomas Grainger for his effort on most of
  these!):

  * Cancel scopes are now properly enforced with native asyncio coroutine functions
    (without any explicit AnyIO checkpoints)
  * Changed the asyncio ``CancelScope`` to raise a ``RuntimeError`` if a cancel scope is
    being exited before it was even entered
  * Changed the asyncio test runner to capture unhandled exceptions from asynchronous
    callbacks and unbound native tasks which are then raised after the test function (or
    async fixture setup or teardown) completes
  * Changed the asyncio ``TaskGroup.start_soon()`` (formerly ``spawn()``) method to call
    the target function immediately before starting the task, for consistency across
    backends
  * Changed the asyncio ``TaskGroup.start_soon()`` (formerly ``spawn()``) method to
    avoid the use of a coroutine wrapper on Python 3.8+ and added a hint for hiding the
    wrapper in tracebacks on earlier Pythons (supported by Pytest, Sentry etc.)
  * Changed the default thread limiter on asyncio to use a ``RunVar`` so it is  scoped
    to the current event loop, thus avoiding potential conflict among multiple running
    event loops
  * Thread pooling is now used on asyncio with ``run_sync_in_worker_thread()``
  * Fixed ``current_effective_deadline()`` raising ``KeyError`` on asyncio when no
    cancel scope is active
- Added the ``RunVar`` class for scoping variables to the running event loop

**2.2.0**

- Added the ``maybe_async()`` and ``maybe_async_cm()`` functions to facilitate forward
  compatibility with AnyIO 3
- Fixed socket stream bug on asyncio where receiving a half-close from the peer would
  shut down the entire connection
- Fixed native task names not being set on asyncio on Python 3.8+
- Fixed ``TLSStream.send_eof()`` raising ``ValueError`` instead of the expected
  ``NotImplementedError``
- Fixed ``open_signal_receiver()`` on asyncio and curio hanging if the cancel scope was
  cancelled before the function could run
- Fixed Trio test runner causing unwarranted test errors on ``BaseException``
  (PR by Matthias Urlichs)
- Fixed formatted output of ``ExceptionGroup`` containing too many newlines

**2.1.0**

- Added the ``spawn_task()`` and ``wrap_async_context_manager()`` methods to
  ``BlockingPortal``
- Added the ``handshake_timeout`` and ``error_handler`` parameters to ``TLSListener``
- Fixed ``Event`` objects on the trio backend not inheriting from ``anyio.abc.Event``
- Fixed ``run_sync_in_worker_thread()`` raising ``UnboundLocalError`` on asyncio when
  cancelled
- Fixed ``send()`` on socket streams not raising any exception on asyncio, and an
  unwrapped ``BrokenPipeError`` on trio and curio when the peer has disconnected
- Fixed ``MemoryObjectSendStream.send()`` raising ``BrokenResourceError`` when the last
  receiver is closed right after receiving the item
- Fixed ``ValueError: Invalid file descriptor: -1`` when closing a ``SocketListener`` on
  asyncio

**2.0.2**

- Fixed one more case of
  ``AttributeError: 'async_generator_asend' object has no attribute 'cr_await'`` on
  asyncio

**2.0.1**

- Fixed broken ``MultiListener.extra()`` (PR by daa)
- Fixed ``TLSStream`` returning an empty bytes object instead of raising ``EndOfStream``
  when trying to receive from the stream after a closing handshake
- Fixed ``AttributeError`` when cancelling a task group's scope inside an async test
  fixture on asyncio
- Fixed ``wait_all_tasks_blocked()`` raising ``AttributeError`` on asyncio if a native
  task is waiting on an async generator's ``asend()`` method

**2.0.0**

- General new features:

  - Added support for subprocesses
  - Added support for "blocking portals" which allow running functions in the event loop
    thread from external threads
  - Added the ``anyio.aclose_forcefully()`` function for closing asynchronous resources
    as quickly as possible

- General changes/fixes:

  - **BACKWARDS INCOMPATIBLE** Some functions have been renamed or removed (see further
    below for socket/fileio API changes):

    - ``finalize()`` → (removed; use ``contextlib.aclosing()`` instead)
    - ``receive_signals()`` → ``open_signal_receiver()``
    - ``run_in_thread()`` → ``run_sync_in_worker_thread()``
    - ``current_default_thread_limiter()`` → ``current_default_worker_thread_limiter()``
    - ``ResourceBusyError`` → ``BusyResourceError``
  - **BACKWARDS INCOMPATIBLE** Exception classes were moved to the top level package
  - Dropped support for Python 3.5
  - Bumped minimum versions of trio and curio to v0.16 and v1.4, respectively
  - Changed the ``repr()`` of ``ExceptionGroup`` to match trio's ``MultiError``

- Backend specific changes and fixes:

  - ``asyncio``: Added support for ``ProactorEventLoop``. This allows asyncio
    applications to use AnyIO on Windows even without using AnyIO as the entry point.
  - ``asyncio``: The asyncio backend now uses ``asyncio.run()`` behind the scenes which
    properly shuts down async generators and cancels any leftover native tasks
  - ``curio``: Worked around the limitation where a task can only be cancelled twice
    (any cancellations beyond that were ignored)
  - ``asyncio`` + ``curio``: a cancellation check now calls ``sleep(0)``, allowing the
    scheduler to switch to a different task
  - ``asyncio`` + ``curio``: Host name resolution now uses `IDNA 2008`_ (with UTS 46
    compatibility mapping, just like trio)
  - ``asyncio`` + ``curio``: Fixed a bug where a task group would abandon its subtasks
    if its own cancel scope was cancelled while it was waiting for subtasks to finish
  - ``asyncio`` + ``curio``: Fixed recursive tracebacks when a single exception from an
    inner task group is reraised in an outer task group

- Socket/stream changes:

  - **BACKWARDS INCOMPATIBLE** The stream class structure was completely overhauled.
    There are now separate abstract base classes for receive and send streams, byte
    streams and reliable and unreliable object streams. Stream wrappers are much better
    supported by this new ABC structure and a new "typed extra attribute" system that
    lets you query the wrapper chain for the attributes you want via ``.extra(...)``.
  - **BACKWARDS INCOMPATIBLE** Socket server functionality has been refactored into a
    network-agnostic listener system
  - **BACKWARDS INCOMPATIBLE** TLS functionality has been split off from
    ``SocketStream`` and can now work over any bidirectional bytes-based stream – you
    can now establish a TLS encrypted communications pathway over UNIX sockets or even
    memory object streams. The ``TLSRequired`` exception has also been removed as it is
    no longer necessary.
  - **BACKWARDS INCOMPATIBLE** Buffering functionality (``receive_until()`` and
    ``receive_exactly()``) was split off from ``SocketStream`` into a stream wrapper
    class (``anyio.streams.buffered.BufferedByteReceiveStream``)
  - **BACKWARDS INCOMPATIBLE** IPv6 addresses are now reported as 2-tuples. If original
    4-tuple form contains a nonzero scope ID, it is appended to the address with ``%``
    as the separator.
  - **BACKWARDS INCOMPATIBLE** Byte streams (including socket streams) now raise
    ``EndOfStream`` instead of returning an empty bytes object when the stream has been
    closed from the other end
  - **BACKWARDS INCOMPATIBLE** The socket API has changes:

    - ``create_tcp_server()`` → ``create_tcp_listener()``
    - ``create_unix_server()`` → ``create_unix_listener()``
    - ``create_udp_socket()`` had some of its parameters changed:

      - ``interface`` → ``local_address``
      - ``port`` → ``local_port``
      - ``reuse_address`` was replaced with ``reuse_port`` (and sets ``SO_REUSEPORT``
        instead of ``SO_REUSEADDR``)
    - ``connect_tcp()`` had some of its parameters changed:

      - ``address`` → ``remote_address``
      - ``port`` → ``remote_port``
      - ``bind_host`` → ``local_address``
      - ``bind_port`` → (removed)
      - ``autostart_tls`` → ``tls``
      - ``tls_hostname`` (new parameter, when you want to match the certificate against
        against something else than ``remote_address``)
    - ``connect_tcp()`` now returns a ``TLSStream`` if TLS was enabled
    - ``notify_socket_closing()`` was removed, as it is no longer used by AnyIO
    - ``SocketStream`` has changes to its methods and attributes:

        - ``address`` → ``.extra(SocketAttribute.local_address)``
        - ``alpn_protocol`` → ``.extra(TLSAttribute.alpn_protocol)``
        - ``close()`` → ``aclose()``
        - ``get_channel_binding`` → ``.extra(TLSAttribute.channel_binding_tls_unique)``
        - ``cipher`` → ``.extra(TLSAttribute.cipher)``
        - ``getpeercert`` → ``.extra(SocketAttribute.peer_certificate)`` or
          ``.extra(SocketAttribute.peer_certificate_binary)``
        - ``getsockopt()`` → ``.extra(SocketAttribute.raw_socket).getsockopt(...)``
        - ``peer_address`` → ``.extra(SocketAttribute.remote_address)``
        - ``receive_chunks()`` → (removed; use ``async for`` on the stream instead)
        - ``receive_delimited_chunks()`` → (removed)
        - ``receive_exactly()`` → ``BufferedReceiveStream.receive_exactly()``
        - ``receive_some()`` → ``receive()``
        - ``receive_until()`` → ``BufferedReceiveStream.receive_until()``
        - ``send_all()`` → ``send()``
        - ``setsockopt()`` → ``.extra(SocketAttribute.raw_socket).setsockopt(...)``
        - ``shared_ciphers`` → ``.extra(TLSAttribute.shared_ciphers)``
        - ``server_side`` → ``.extra(TLSAttribute.server_side)``
        - ``start_tls()`` → ``stream = TLSStream.wrap(...)``
        - ``tls_version`` → ``.extra(TLSAttribute.tls_version)``
    - ``UDPSocket`` has changes to its methods and attributes:

      - ``address`` → ``.extra(SocketAttribute.local_address)``
      - ``getsockopt()`` → ``.extra(SocketAttribute.raw_socket).getsockopt(...)``
      - ``port`` → ``.extra(SocketAttribute.local_port)``
      - ``receive()`` no longer takes a maximum bytes argument
      - ``receive_packets()`` → (removed; use ``async for`` on the UDP socket instead)
      - ``send()`` → requires a tuple for destination now (address, port), for
        compatibility with the new ``UnreliableObjectStream`` interface. The
        ``sendto()`` method works like the old ``send()`` method.
      - ``setsockopt()`` → ``.extra(SocketAttribute.raw_socket).setsockopt(...)``
  - **BACKWARDS INCOMPATIBLE** Renamed the ``max_size`` parameter to ``max_bytes``
    wherever it occurred (this was inconsistently named ``max_bytes`` in some subclasses
    before)
  - Added memory object streams as a replacement for queues
  - Added stream wrappers for encoding/decoding unicode strings
  - Support for the ``SO_REUSEPORT`` option (allows binding more than one socket to the
    same address/port combination, as long as they all have this option set) has been
    added to TCP listeners and UDP sockets
  - The ``send_eof()`` method was added to all (bidirectional) streams

- File I/O changes:

  - **BACKWARDS INCOMPATIBLE** Asynchronous file I/O functionality now uses a common
    code base (``anyio.AsyncFile``) instead of backend-native classes
  - **BACKWARDS INCOMPATIBLE** The File I/O API has changes to its functions and
    methods:

    - ``aopen()`` → ``open_file()``
    - ``AsyncFileclose()`` → ``AsyncFileaclose()``

- Task synchronization changes:

  - **BACKWARDS INCOMPATIBLE** Queues were replaced by memory object streams
  - **BACKWARDS INCOMPATIBLE** Added the ``acquire()`` and ``release()`` methods to the
    ``Lock``, ``Condition`` and ``Semaphore`` classes
  - **BACKWARDS INCOMPATIBLE** Removed the ``Event.clear()`` method. You must now
    replace the event object with a new one rather than clear the old one.
  - Fixed ``Condition.wait()`` not working on asyncio and curio (PR by Matt Westcott)

- Testing changes:

  - **BACKWARDS INCOMPATIBLE** Removed the ``--anyio-backends`` command line option for
    the pytest plugin. Use the ``-k`` option to do ad-hoc filtering, and the
    ``anyio_backend`` fixture to control which backends you wish to run the tests by
    default.
  - The pytest plugin was refactored to run the test and all its related async fixtures
    inside the same event loop, making async fixtures much more useful
  - Fixed Hypothesis support in the pytest plugin (it was not actually running the
    Hypothesis tests at all)

.. _IDNA 2008: https://tools.ietf.org/html/rfc5895

**1.4.0**

- Added async name resolution functions (``anyio.getaddrinfo()`` and
  ``anyio.getnameinfo()``)
- Added the ``family`` and ``reuse_address`` parameters to ``anyio.create_udp_socket()``
  (Enables multicast support; test contributed by Matthias Urlichs)
- Fixed ``fail.after(0)`` not raising a timeout error on asyncio and curio
- Fixed ``move_on_after()`` and ``fail_after()`` getting stuck on curio in some
  circumstances
- Fixed socket operations not allowing timeouts to cancel the task
- Fixed API documentation on ``Stream.receive_until()`` which claimed that the delimiter
  will be included in the returned data when it really isn't
- Harmonized the default task names across all backends
- ``wait_all_tasks_blocked()`` no longer considers tasks waiting on ``sleep(0)`` to be
  blocked on asyncio and curio
- Fixed the type of the ``address`` parameter in ``UDPSocket.send()`` to include
  ``IPAddress`` objects (which were already supported by the backing implementation)
- Fixed ``UDPSocket.send()`` to resolve host names using ``anyio.getaddrinfo()`` before
  calling ``socket.sendto()`` to avoid blocking on synchronous name resolution
- Switched to using ``anyio.getaddrinfo()`` for name lookups

**1.3.1**

- Fixed warnings caused by trio 0.15
- Worked around a compatibility issue between uvloop and Python 3.9 (missing
  ``shutdown_default_executor()`` method)

**1.3.0**

- Fixed compatibility with Curio 1.0
- Made it possible to assert fine grained control over which AnyIO backends and backend
  options are being used with each test
- Added the ``address`` and ``peer_address`` properties to the ``SocketStream``
  interface

**1.2.3**

- Repackaged release (v1.2.2 contained extra files from an experimental
  branch which broke imports)

**1.2.2**

- Fixed ``CancelledError`` leaking from a cancel scope on asyncio if the task previously
  received a cancellation exception
- Fixed ``AttributeError`` when cancelling a generator-based task (asyncio)
- Fixed ``wait_all_tasks_blocked()`` not working with generator-based tasks (asyncio)
- Fixed an unnecessary delay in ``connect_tcp()`` if an earlier attempt succeeds
- Fixed ``AssertionError`` in ``connect_tcp()`` if multiple connection attempts succeed
  simultaneously

**1.2.1**

- Fixed cancellation errors leaking from a task group when they are contained in an
  exception group
- Fixed trio v0.13 compatibility on Windows
- Fixed inconsistent queue capacity across backends when capacity was defined as 0
  (trio = 0, others = infinite)
- Fixed socket creation failure crashing ``connect_tcp()``

**1.2.0**

- Added the possibility to parametrize regular pytest test functions against the
  selected list of backends
- Added the ``set_total_tokens()`` method to ``CapacityLimiter``
- Added the ``anyio.current_default_thread_limiter()`` function
- Added the ``cancellable`` parameter to ``anyio.run_in_thread()``
- Implemented the Happy Eyeballs (:rfc:`6555`) algorithm for ``anyio.connect_tcp()``
- Fixed ``KeyError`` on asyncio and curio where entering and exiting a cancel scope
  happens in different tasks
- Fixed deprecation warnings on Python 3.8 about the ``loop`` argument of
  ``asyncio.Event()``
- Forced the use ``WindowsSelectorEventLoopPolicy`` in ``asyncio.run`` when on Windows
  and asyncio
  to keep network functionality working
- Worker threads are now spawned with ``daemon=True`` on all backends, not just trio
- Dropped support for trio v0.11

**1.1.0**

- Added the ``lock`` parameter to ``anyio.create_condition()`` (PR by Matthias Urlichs)
- Added async iteration for queues (PR by Matthias Urlichs)
- Added capacity limiters
- Added the possibility of using capacity limiters for limiting the maximum number of
  threads
- Fixed compatibility with trio v0.12
- Fixed IPv6 support in ``create_tcp_server()``, ``connect_tcp()`` and
  ``create_udp_socket()``
- Fixed mishandling of task cancellation while the task is running a worker thread on
  asyncio and curio

**1.0.0**

- Fixed pathlib2_ compatibility with ``anyio.aopen()``
- Fixed timeouts not propagating from nested scopes on asyncio and curio (PR by Matthias
  Urlichs)
- Fixed incorrect call order in socket close notifications on asyncio (mostly affecting
  Windows)
- Prefixed backend module names with an underscore to better indicate privateness

 .. _pathlib2: https://pypi.org/project/pathlib2/

**1.0.0rc2**

- Fixed some corner cases of cancellation where behavior on asyncio and curio did not
  match with that of trio. Thanks to Joshua Oreman for help with this.
- Fixed ``current_effective_deadline()`` not taking shielded cancellation scopes into
  account on asyncio and curio
- Fixed task cancellation not happening right away on asyncio and curio when a cancel
  scope is entered when the deadline has already passed
- Fixed exception group containing only cancellation exceptions not being swallowed by a
  timed out cancel scope on asyncio and curio
- Added the ``current_time()`` function
- Replaced ``CancelledError`` with ``get_cancelled_exc_class()``
- Added support for Hypothesis_
- Added support for :pep:`561`
- Use uvloop for the asyncio backend by default when available (but only on CPython)

.. _Hypothesis: https://hypothesis.works/

**1.0.0rc1**

- Fixed ``setsockopt()`` passing options to the underlying method in the wrong manner
- Fixed cancellation propagation from nested task groups
- Fixed ``get_running_tasks()`` returning tasks from other event loops
- Added the ``parent_id`` attribute to ``anyio.TaskInfo``
- Added the ``get_current_task()`` function
- Added guards to protect against concurrent read/write from/to sockets by multiple
  tasks
- Added the ``notify_socket_close()`` function

**1.0.0b2**

- Added introspection of running tasks via ``anyio.get_running_tasks()``
- Added the ``getsockopt()`` and ``setsockopt()`` methods to the ``SocketStream`` API
- Fixed mishandling of large buffers by ``BaseSocket.sendall()``
- Fixed compatibility with (and upgraded minimum required version to) trio v0.11

**1.0.0b1**

- Initial release
