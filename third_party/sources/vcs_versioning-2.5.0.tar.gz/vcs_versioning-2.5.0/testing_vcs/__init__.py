"""Tests for vcs-versioning."""
